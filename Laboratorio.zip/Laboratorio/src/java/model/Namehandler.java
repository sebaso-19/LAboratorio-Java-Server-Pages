/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.util.Date;
import java.util.Calendar;
import java.util.Locale;
import javax.swing.text.html.parser.DTD;
/**
 *
 * @author ANGRY
 */
public class Namehandler {
    private String name;
    private int ano;

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAno() {
        ano = 2023-ano;
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
    
    
}
